#pragma once

#include "Account.h"

class SavAccount : public Account {
public:
    SavAccount(double balance);
};