#pragma once

#include "Account.h"

class CurrAccount : public Account {
public:
    CurrAccount(double balance);
};